---
name: hwpx
description: "Use this skill whenever the user wants to create, read, edit, analyze, or manipulate Hangul/Korean word processor documents (.hwpx, .hwp, .owpml files). Triggers include: any mention of 'hwpx', 'hwp', '한글 파일', '한글 문서', '한컴', 'OWPML', or requests to produce Korean government forms, fill templates, clone forms, or convert documents. Also use when converting HWP to HWPX (hwp2hwpx), extracting text from .hwpx files, filling form fields, checking/unchecking boxes, generating multiple filled documents, converting HTML/Markdown to .hwpx format, extracting images from HWP/HWPX documents, analyzing document contents (text, tables, images), or extracting/applying document themes and styles. If the user asks to '이미지 추출', '문서 분석', '표 데이터 추출', '이미지 내용 파악', or any Korean document operation, use this skill. Do NOT use for .docx Word documents, PDFs, or spreadsheets."
---

# HWPX creation, editing, and form automation

## 절대 규칙 — 이 스킬의 모든 작업에 적용

1. **pyhwpxlib만 사용한다.** 자체 코드를 작성하거나 다른 라이브러리로 우회하지 않는다.
2. `.hwp` 파일이 들어오면 **반드시 `pyhwpxlib.hwp2hwpx.convert()`로 HWPX 변환부터** 한다. olefile 직접 읽기, 바이너리 파싱 등 다른 방법을 시도하지 않는다.
3. `.hwpx` 파일이 들어오면 **반드시 `pyhwpxlib.api.extract_text()`로 읽는다.** zipfile로 직접 열거나 xml.etree로 직접 파싱하지 않는다.
4. 새 문서 생성은 **반드시 `from pyhwpxlib import HwpxBuilder`를 사용한다.** XML을 직접 작성하지 않는다.
5. 문서 편집은 **반드시 `pyhwpxlib unpack → 문자열 교체 → pyhwpxlib pack` 순서**를 따른다.
6. **HWPX를 생성/편집/변환한 후에는 반드시 PNG 프리뷰를 생성하고 Read tool로 직접 확인한다.** 이 단계를 건너뛰지 않는다. 문제가 발견되면 자동으로 수정하고 다시 프리뷰한다.
```python
# 모든 워크플로우의 필수 검증 단계 — 생략 금지
from pyhwpxlib.preview import render_pages
pages = render_pages(output_path, '/tmp')
# 반드시 Read tool로 각 페이지 PNG 확인 → 문제 발견 시 수정 후 재프리뷰
```

위 규칙을 어기면 Whale/한컴오피스에서 파일이 열리지 않거나 서식이 깨진다.
규칙 6을 어기면 사용자에게 깨진 문서를 전달하게 된다.

## 디자인 규칙 — 새 문서 생성 시 반드시 적용

지루한 문서를 만들지 마라. 자세한 가이드: [references/design_guide.md](references/design_guide.md)

1. **주제에 맞는 테마를 선택한다** — `HwpxBuilder(theme='forest')` 한 줄로 색상+폰트+사이즈 적용. 10종 내장 테마 사용
2. **시각 요소는 내용에 맞을 때만** — 표/목록/박스는 데이터나 비교가 있을 때 사용. 서술형 내용은 문단만으로 충분. 억지로 표를 만들지 않는다
3. **같은 레이아웃 반복 금지** — 표→목록→박스→인용문 순환
4. **AI 생성 패턴 피하기** — 제목 아래 악센트 라인, 매번 같은 표지, 모든 섹션 동일 구조
5. **QA 필수** — 생성 후 validate + 사용자에게 Whale 확인 요청. 문제가 있다고 가정하고 찾는다
6. **문단 간격 필수** — HWPX는 기본 간격이 0이므로 `add_paragraph("")`로 빈 줄을 넣어야 한다
   - `add_heading()` 앞뒤에 빈 줄 (첫 헤딩 앞 제외)
   - `add_table()` 앞뒤에 빈 줄
   - `add_image()` 앞뒤에 빈 줄

---

## On Load — 스킬 로드 시 즉시 실행

이 스킬이 로드되면 **반드시** 아래 흐름을 따른다. 이 단계를 건너뛰지 않는다.

사용자의 메시지에 구체적인 작업이 포함되어 있지 않은 경우, **반드시 AskUserQuestion을 호출**하여 작업을 물어본다:

```
"어떤 작업을 하시겠어요?"

1. 새 문서 만들기 — HwpxBuilder로 보고서, 공문서, 양식 등 생성
2. 기존 문서 편집 — hwpx 파일의 텍스트/서식 수정 (unpack → edit → pack)
3. 양식 자동화 — 서식 템플릿에 데이터 채우기, 다건 생성, 스키마 추출
4. 문서 변환 — MD→HWPX, HTML→HWPX, HWPX→HTML, HWP 5.x 읽기
5. 문서 분석 — 텍스트·표·이미지 추출 + 이미지 내용 파악 (Vision)
```

사용자가 이미 구체적인 요청을 했으면 (예: "이 hwp 파일 읽어줘", "보고서 만들어줘") 질문 없이 바로 해당 작업을 진행한다. 단, 해당 워크플로우의 각 단계는 **반드시 AskUserQuestion으로 진행**한다 — 단계를 건너뛰고 혼자 판단하지 않는다.

**자동 감지 규칙** — 파일 확장자에 따라 자동 판단:
- 사용자가 `.hwp` 파일을 주면 → **먼저 hwp2hwpx로 HWPX 변환** 후 작업 진행
- 사용자가 `.hwpx` 파일을 주면 → 바로 읽기/편집/양식 채우기 진행
- 사용자가 `.md` 파일을 주면 → md2hwpx 또는 LLM+HwpxBuilder로 변환
- 사용자가 `.html` 파일을 주면 → convert_html_file_to_hwpx로 변환
- 사용자가 텍스트만 주면 → HwpxBuilder로 새 문서 생성

```python
# .hwp 파일 감지 시 자동 실행
from pyhwpxlib.hwp_reader import detect_format
fmt = detect_format(file_path)  # "HWP" or "HWPX"
if fmt == "HWP":
    from pyhwpxlib.hwp2hwpx import convert
    hwpx_path = file_path.replace('.hwp', '.hwpx')
    convert(file_path, hwpx_path)
    # 이후 hwpx_path로 작업 진행
```

**워크플로우 [1] 새 문서 만들기**:

Step A: 테마 선택 — 저장된 커스텀 양식이 있으면 먼저 제안
```python
from pyhwpxlib.themes import _THEMES_DIR, BUILTIN_THEMES, load_theme
customs = sorted(_THEMES_DIR.glob('*.json')) if _THEMES_DIR.exists() else []
```
저장된 양식이 있으면:
```
"어떤 스타일로 만들까요?"
1. AFC점검양식 (primary=#2E74B5, 함초롬돋움)  ← 저장된 양식
2. 소방서양식 (primary=#333399, 맑은 고딕)     ← 저장된 양식
3. 내장 테마에서 선택 (10종)
4. 새 스타일 (주제에 맞게 자동 선택)
```
저장된 양식이 없으면: "어떤 유형?" → 정부양식/공문서/보고서/세무법무/논문/자유
Step B: (저장된 양식 선택 시) `theme = load_theme('양식이름')` / (내장 선택 시) 주제에 맞는 테마
Step C: AskUserQuestion — "내용을 알려주세요"
Step D: 실행
```python
from pyhwpxlib import HwpxBuilder
doc = HwpxBuilder(theme='custom/AFC점검양식')  # 또는 theme='forest'
# 테마가 색상+폰트+사이즈를 자동 적용. 매 섹션 시각 요소 포함, 같은 레이아웃 반복 금지
doc.add_heading(제목, level=1)  # 테마 primary 색상 + h1 사이즈 자동
doc.add_paragraph(본문)  # 테마 body 사이즈 자동
doc.add_table(data)  # 테마 primary 헤더 배경 자동

# 이미지 — 텍스트만 있는 문서는 지루하다. 적극 활용할 것.
doc.add_image("logo.png", width=10000, height=5000)  # 로컬 파일
doc.add_image_from_url("https://...", filename="chart.png",  # URL 다운로드
    width=21260, height=15000)
doc.save(파일명)
```

**이미지 활용 기준** — 문서에 이미지가 필요한 경우 빠뜨리지 않는다:
- 사용자가 이미지 파일을 제공하면 → `add_image()`로 삽입
- 사용자가 이미지 URL을 언급하면 → `add_image_from_url()`로 다운로드+삽입
- 로고, 직인, 사진이 필요한 문서 유형이면 → 사용자에게 이미지 파일을 요청
- 기존 문서에 이미지 추가 → `insert_image_to_existing(hwpx, image, output)`
Step E: `pyhwpxlib validate 파일명`
Step F: **시각 검토 (생략 금지)** — HWPX → PNG → Read tool로 직접 본다
```python
from pyhwpxlib.preview import render_pages
pages = render_pages(파일명, '/tmp')  # embed_fonts=True 기본
# 반환값의 png 경로를 Read tool로 실제로 열어라.
```
**rhwp 프리뷰 알려진 한계** (Whale에서는 정상):
- 이미지와 텍스트 겹침 — rhwp가 `textWrap="TOP_AND_BOTTOM"` 미지원, 이미지 높이만큼 텍스트를 밀어내지 못함
- linesegarray 불일치 — 텍스트 교체 후 줄 배치가 뭉칠 수 있음 (Whale은 자동 재계산)
- 프리뷰에서 이미지 겹침이 보여도 **Whale에서 정상이면 문제 없음**

그 다음 반드시 아래 7가지 비주얼 체크포인트를 글로 적어 스스로 확인한다.
**문제가 없다고 판단했으면 더 비판적으로 다시 본다. 첫 렌더는 거의 항상 문제가 있다.**

**1. 시각적 계층 (Visual Hierarchy)**
- 제목/소제목/본문 크기 차이가 충분한가? (제목 24pt+ vs 본문 12pt — 2배 이상 차이)
- 표지가 있으면: 제목이 페이지 중앙에 충분히 크게 보이나? (28pt+)
- 한 페이지에 하나의 시각적 초점이 있나?

**2. 색상 & 대비 (Color & Contrast)**
- 테마 primary 색상이 제목/표 헤더에 적용되었나?
- 표 헤더 배경 위 텍스트가 읽히는가? (어두운 배경 → 흰 글자, 밝은 배경 → 어두운 글자)
- 전체 문서에서 색상이 3가지 이내로 일관되나? (primary + 본문 + 메타)
- 기본 파란색(#395da2)이 아닌 주제에 맞는 색상인가?

**3. 타이포그래피 (Typography)**
- 폰트 깨짐(□ 치환 문자, 빈 사각형) 없는가?
- 제목/본문 폰트가 구분되는가? (커스텀 FontSet 사용 시)
- 글자 간격이 너무 넓거나 겹치지 않는가?

**4. 레이아웃 & 공간 (Layout & Spacing)**
- 텍스트/표가 페이지 밖으로 넘치지 않는가?
- 빈 페이지가 의도치 않게 생기지 않았나?
- 표가 페이지 경계에서 잘리지 않았나?
- 여백이 일정한가? (좌우 균형, 상하 여유)
- 요소 간 간격이 균등한가? (한쪽은 빽빽, 한쪽은 텅 빔 없는지)

**5. 표 스타일 (Table)**
- 헤더 행에 배경색이 적용되었나?
- 헤더 텍스트 색상이 배경과 대비되나?
- 셀 패딩이 적절한가? (글자가 셀 테두리에 붙지 않는지)
- 컬럼 너비가 내용에 맞게 분배되었나?

**6. 원본 대조 (편집/양식 채우기 시)**
- 원본과 같은 위치에 같은 구조인가?
- 교체 안 된 텍스트가 남아있지 않은가?
- 표, 이미지, 중첩 표가 원본과 동일한가?

**7. AI 생성 패턴 피하기 (Anti-Slop)**
- 모든 섹션이 동일한 레이아웃 반복 아닌가? (표→목록→박스 순환)
- 제목 아래 불필요한 악센트 라인 없는가?
- 텍스트만 있는 섹션 없는가? (시각 요소 최소 1개)

관찰을 쓰지 않고 "완료" 보고 금지. 문제 발견 시 Step C로 복귀하여 자동 수정.
**수정 후 반드시 재렌더링하여 재검증** — 한 번의 수정이 다른 문제를 만들 수 있다.
의존성: `pip install pyhwpxlib[preview-fonts]` (wasmtime + Pillow + fonttools)
Step G: AskUserQuestion — "Whale에서도 열어 확인해주세요. 수정할 부분 있나요?" → 있으면 Step C로
Step H: **양식 저장 제안** — 문서가 완성되면 제안한다:
```
"이 스타일을 양식으로 저장하면 다음에 같은 스타일로 바로 만들 수 있어요.
 저장할까요? 저장할 이름을 알려주세요. (예: 회의록양식, 사내보고서)"
```
사용자가 원하면:
```python
from pyhwpxlib import extract_theme, save_theme
theme = extract_theme('output.hwpx', name='사용자가_지정한_이름')
path = save_theme(theme)
# "양식 '사내보고서'가 저장되었습니다. 다음에 '사내보고서 스타일로 만들어줘'라고 하면 됩니다."
```

**워크플로우 [2] 기존 문서 편집**:

Step A: AskUserQuestion — "파일 경로?"
Step B: 자동 감지 + 텍스트 추출
```python
from pyhwpxlib.hwp_reader import detect_format
if detect_format(path) == "HWP":
    from pyhwpxlib.hwp2hwpx import convert
    convert(path, hwpx_path)
from pyhwpxlib.api import extract_text
print(extract_text(hwpx_path))  # 사용자에게 내용 보여주기
```
Step C: AskUserQuestion — "어떤 편집?" → 텍스트 교체/구조 수정/양식 채우기
Step D: 실행
```bash
pyhwpxlib unpack doc.hwpx -o unpacked/
# 원본 문자열 교체 (ET.tostring 금지!)
pyhwpxlib pack unpacked/ -o output.hwpx
pyhwpxlib validate output.hwpx
```
Step E: AskUserQuestion — "수정할 부분 있나요?"

**워크플로우 [3] 양식 자동화 (시각 분석 기반)**:

Step A: AskUserQuestion — "양식 파일 경로?"
Step B: rhwp 프리뷰 렌더링 → **Claude가 PNG 이미지를 보고 양식 분석**
```python
# 1. 프리뷰 렌더링
from pyhwpxlib.preview import render_pages
pages = render_pages(template_path, '/tmp')
# 2. Read tool로 각 페이지 PNG 확인
# 3. Claude가 시각적으로 분석:
#    - 문서 제목/유형 파악
#    - 빈 칸 = 입력란 식별
#    - 각 입력란에 사람이 읽는 이름(placeholder) 부여
#    - 날짜란, 서명란 등 특수 필드 감지
```
Step C: 분석 결과를 사용자에게 보여주기
```
"이 양식은 '의견제출서'입니다. 다음 정보를 입력해주세요:
 1. 성명 (필수)
 2. 전화번호 (필수)
 3. 주소 (필수)
 4. 의견 (필수)
 5. 날짜 (필수)"
```
Step D: AskUserQuestion — "위 정보를 입력해주세요" → 대화형/JSON/CSV

Step E-pre: **양식 구조 분기 판정** (필수)

양식은 두 가지 구조로 나뉜다. 성급히 `fill_by_labels`를 호출하면 안 되는 케이스가 많다.

```python
import sys; sys.path.insert(0, 'templates')
from form_pipeline import extract_form
form = extract_form(template_path)
# 각 셀의 text를 확인. 레이블과 값이 같은 셀 안에 있는지 체크.
for tbl in form['tables']:
    for cell in tbl.get('cells', []):
        text = ' '.join(r.get('text','') for line in cell.get('lines',[])
                        for r in line.get('runs',[]))
        # "성 명  홍길동" 처럼 레이블 뒤 공백만 있는 셀 = "같은 셀" 구조
        # "성 명" 셀 옆에 별도 빈 셀 = "인접 셀" 구조
```

- **구조 A (인접 셀)**: 레이블 셀과 값 셀이 분리 → `fill_by_labels` 사용 가능
- **구조 B (같은 셀)**: 레이블+값 placeholder가 한 셀 안 (예: `"성 명       "`, `"전화번호    (      )         - "`) → `fill_by_labels` **사용 금지**. `unpack → 원본 문자열 교체 → pack` 으로 폴백.

**구조 B 폴백 코드**:
```bash
pyhwpxlib unpack template.hwpx -o /tmp/unp
```
```python
with open('/tmp/unp/Contents/section0.xml', 'r', encoding='utf-8') as f:
    xml = f.read()
# 원본 문자열 유일성 확보 후 교체. ET.tostring 금지.
xml = xml.replace('<hp:t>주 소 </hp:t>',
                  '<hp:t>주 소  서울시 강남구 테헤란로 123</hp:t>', 1)
with open('/tmp/unp/Contents/section0.xml', 'w', encoding='utf-8') as f:
    f.write(xml)
```
```bash
pyhwpxlib pack /tmp/unp -o output.hwpx
```

Step E: 판정 결과에 따라 실행
```python
# 구조 A 경우에만:
from form_pipeline import fill_by_labels
fill_by_labels(template_path, {
    '성 명>right': user_data['성명'],
}, output_path)
# 빈 셀은 내부적으로 cellAddr 기반 _patch_empty_cell로 자동 채움.
```
Step F: rhwp 프리뷰로 결과 검증 → 문제 발견 시 Step E로 자동 수정
Step G: AskUserQuestion — "Whale에서도 확인해주세요. 수정할 부분?" → 있으면 Step E로
Step H: **양식 저장 제안** — 완성된 양식의 스타일을 저장할지 제안 (워크플로우 [1] Step H와 동일)

**워크플로우 [4] 문서 변환**:

Step A: AskUserQuestion — "변환 유형?" → HWP→HWPX / MD→HWPX / HTML→HWPX / HWPX→HTML
Step B: AskUserQuestion — "파일 경로?"
Step C: 실행
```python
# HWP→HWPX
from pyhwpxlib.hwp2hwpx import convert
convert(hwp_path, hwpx_path)

# MD→HWPX
# pyhwpxlib md2hwpx input.md -o output.hwpx

# HTML→HWPX
from pyhwpxlib.api import convert_html_file_to_hwpx
convert_html_file_to_hwpx(html_path, hwpx_path)
```
Step D: `pyhwpxlib validate output` → 결과 요약
Step E: AskUserQuestion — "다음 작업?" → 편집/추가 변환/완료
Step F: **양식 저장 제안** — 변환된 문서의 스타일을 저장할지 제안 (워크플로우 [1] Step H와 동일)

**워크플로우 [5] Excel → HWPX 보고서 생성**:

Step A: AskUserQuestion — "Excel 파일 경로? + 양식/스타일 지정?"
Step B: Excel 읽기 + 구조 파악
```python
import openpyxl
wb = openpyxl.load_workbook(xlsx_path, data_only=True)
# 시트명, 행/열 수, 헤더, 데이터 요약을 사용자에게 보여주기
```
Step C: AskUserQuestion — "어떤 데이터를 어떻게 정리할까요?" → 요약표/상세표/차트 등
Step D: HwpxBuilder로 보고서 생성
```python
from pyhwpxlib import HwpxBuilder
doc = HwpxBuilder()
# 제목, 메타 정보, 요약표, 상세표 순서로 구성
# 긴 텍스트는 _hard_wrap() 적용 (규칙 #13)
# 긴 표는 페이지 청킹 (규칙 #14)
doc.save(output_path)
```
Step E: rhwp 프리뷰로 시각 검토 (Step F와 동일)
Step F: AskUserQuestion — "수정할 부분 있나요?" → 있으면 Step D로

**워크플로우 [6] 문서 분석 — 텍스트·표·이미지 추출 + Vision**:

Step A: AskUserQuestion — "분석할 파일 경로?"
Step B: 자동 감지 + HWPX 변환 (HWP인 경우)
```python
from pyhwpxlib.hwp_reader import detect_format
if detect_format(path) == "HWP":
    from pyhwpxlib.hwp2hwpx import convert
    convert(path, hwpx_path)
```
Step C: 텍스트 + 표 + 이미지 메타데이터를 JSON으로 추출
```python
from pyhwpxlib.json_io.overlay import extract_overlay
overlay = extract_overlay(hwpx_path)
# overlay['texts']  — 본문 텍스트 목록
# overlay['tables'] — 표 목록 (id, context, rows, cols)
# overlay['images'] — 이미지 메타데이터 (href, width, height)
```
Step D: 이미지 파일 추출 + Claude Vision으로 내용 파악
```python
import zipfile, os
out_dir = '/tmp/hwpx_images'
os.makedirs(out_dir, exist_ok=True)
with zipfile.ZipFile(hwpx_path) as z:
    for name in z.namelist():
        if name.startswith('BinData/'):
            data = z.read(name)
            fname = name.split('/')[-1]
            # BMP → PNG 변환 (Read tool이 BMP를 못 읽음)
            out_path = os.path.join(out_dir, fname)
            with open(out_path, 'wb') as f:
                f.write(data)
            if fname.lower().endswith('.bmp'):
                from PIL import Image
                png_path = out_path.rsplit('.', 1)[0] + '.png'
                Image.open(out_path).save(png_path)
                out_path = png_path
            # Read tool로 각 이미지를 직접 본다 → 내용 설명
```
각 이미지를 Read tool로 열어보고, 내용을 설명한다:
- 사진이면: 무엇이 찍혀 있는지 (예: "빨간색 구명조끼, 성인용")
- 로고/아이콘이면: 텍스트와 의미 (예: "119 소방서 로고")
- 차트/그래프면: 데이터를 표로 변환
- 스캔 문서/캡처면: OCR로 텍스트 추출

Step E: 분석 결과를 구조화하여 사용자에게 제공
```
"이 문서를 분석했습니다:

📝 텍스트: 36개 단락
📊 표: 21개 (신청서, FAQ, 대여물품 현황 등)
🖼️ 이미지: 6개
  1. BIN0001.png — 빨간색 구명조끼 (성인용)
  2. BIN0002.png — 빨간색 구명조끼 (다른 각도)
  3. BIN0003.png — 빨간색 구명조끼 (또 다른 각도)
  4. BIN0004.png — 형광 아동용 구명조끼
  5. BIN0005.bmp — 119 소방서 로고
  6. BIN0006.bmp — '입고풍당' 서비스 로고

전체 데이터를 JSON으로 내보내거나, 특정 표/이미지를 자세히 볼 수 있습니다."
```
Step F: AskUserQuestion — "추가 분석이 필요한가요?" → JSON 내보내기 / 특정 표 상세 / 이미지 OCR / 완료

모든 흐름의 마지막은 **"수정할 부분이 있으면 알려주세요"**로 끝나고, 사용자가 만족할 때까지 반복한다.

---

## Quick Reference

| Task | Approach |
|------|----------|
| **Preview (시각 검토)** | `from pyhwpxlib.preview import render_pages; render_pages(file, out_dir)` |
| **Excel → HWPX** | `openpyxl`로 읽기 → `HwpxBuilder`로 보고서 생성 (워크플로우 [5]) |
| **문서 분석 (텍스트+표+이미지)** | `extract_overlay()` → JSON + BinData 이미지 추출 + Vision (워크플로우 [6]) |
| Read/extract text | `pyhwpxlib.api.extract_text()` or unpack for raw XML |
| Create new document | Use `HwpxBuilder` — see Creating New Documents below |
| Edit existing document | Unpack → edit XML → repack — see Editing Existing Documents below |
| Fill form template | `fill_template_checkbox()` — see [references/form_automation.md](references/form_automation.md) |
| Batch generate | `fill_template_batch()` — multiple files from one template |
| Convert MD → HWPX | `pyhwpxlib md2hwpx input.md -o output.hwpx` |
| Convert HTML → HWPX | `convert_html_file_to_hwpx(html_path, hwpx_path)` |
| **Convert HWP → HWPX** | `pyhwpxlib.hwp2hwpx.convert(hwp_path, hwpx_path)` |
| Read HWP 5.x binary | `pyhwpxlib.hwp_reader.read_hwp()` |
| Analyze form fields | `extract_schema()` + `analyze_schema_with_llm()` |

---

## Creating New Documents

Generate .hwpx files with `HwpxBuilder`, then validate.

### 테마 시스템 (v0.5+)

`HwpxBuilder(theme='name')` 한 줄로 색상+폰트+사이즈가 자동 적용된다. 10종 내장 테마:

| 테마명 | Primary | 용도 |
|--------|---------|------|
| `default` | `#395da2` 파랑 | 공문서, 기업 보고서 (기본) |
| `forest` | `#2C5F2D` 초록 | 환경, ESG, 성장 전략 |
| `warm_executive` | `#B85042` 적갈 | 제안서, 브랜딩 |
| `ocean_analytics` | `#065A82` 청록 | 데이터 분석, 리서치 |
| `coral_energy` | `#F96167` 코랄 | 마케팅, 캠페인 |
| `charcoal_minimal` | `#36454F` 차콜 | 미니멀, 기술 문서 |
| `teal_trust` | `#028090` 청록 | 의료, 금융 |
| `berry_cream` | `#6D2E46` 와인 | 교육, 문화 |
| `sage_calm` | `#84B59F` 연초록 | 웰빙, 상담 |
| `cherry_bold` | `#990011` 빨강 | 강한 주장, 경고 |

```python
from pyhwpxlib import HwpxBuilder, BUILTIN_THEMES

doc = HwpxBuilder(theme='forest')  # 테마 한 줄로 적용
doc.add_heading("제목", level=1)   # forest primary 색상 자동
doc.add_paragraph("본문")          # 테마 body 사이즈 자동
doc.add_table([["A", "B"]])       # forest 초록 헤더 자동
```

**커스텀 테마 (폰트/사이즈 변경)**:
```python
from pyhwpxlib.themes import Theme, Palette, FontSet, SizeSet, Margins, BUILTIN_THEMES

custom = Theme(
    name='my_theme',
    palette=BUILTIN_THEMES['forest'].palette,  # 기존 팔레트 재사용
    fonts=FontSet(
        heading_hangul='나눔스퀘어Bold', heading_latin='Arial',
        body_hangul='나눔명조', body_latin='Times New Roman',
        caption_hangul='맑은고딕', caption_latin='Verdana',
    ),
    sizes=SizeSet(h1=28, h2=22, h3=18, h4=16, body=14, caption=11),
    margins=BUILTIN_THEMES['forest'].margins,
)
doc = HwpxBuilder(theme=custom)
```

### 문서 프리셋 (공문서/보고서/제안서)

문서 유형에 따라 프리셋을 선택하면 여백, 폰트 크기, 번호 체계, 표지/결문이 자동 적용된다.

```python
from pyhwpxlib import HwpxBuilder
from pyhwpxlib.presets import get_preset, build_cover_page, build_official_footer

preset = get_preset('report')  # 'official' | 'report' | 'proposal'
doc = HwpxBuilder(theme='ocean_analytics')  # 테마 + 프리셋 조합 가능
```

| 프리셋 | 용도 | 여백(mm) | 제목 | 줄간격 | 번호 체계 |
|--------|------|----------|------|--------|-----------|
| `official` | 공문서 | 좌우20, 상30, 하15 | 16pt Bold | 180% | 1. 가. 1) 가) |
| `report` | 보고서 | 좌우30, 상하25 | 18pt Bold | 170% | 제1장 제1절 |
| `proposal` | 제안서 | 좌우25, 상하20 | 22pt Bold | 160% | 1. 1.1 1.1.1 |

**표지 생성**:
```python
build_cover_page(doc, preset,
    title="AI 기반 공공서비스 혁신 방안 연구",
    subtitle="최종 보고서",
    organization="(사)한국정보화진흥원",
    date="2026년 3월")
# → 페이지 브레이크 자동 포함
```

**공문서 결문**:
```python
build_official_footer(doc, preset,
    sender="행정안전부장관",
    drafter="사무관 홍길동", reviewer="서기관 김철수", approver="국장 이영희",
    doc_number="디지털정부국-2026-456", date="2026. 3. 9.",
    address="우) 03171 서울특별시 종로구 세종대로 209",
    website="www.mois.go.kr", phone="044-205-0000", fax="044-205-0001")
```

**프리셋 색상 활용**:
```python
colors = preset['colors']
doc.add_table(data,
    header_bg=colors['table_header'],
    cell_styles={(0,0): {'text_color': colors['table_header_text'], 'bold': True}})
doc.add_table([['하이라이트 박스']],
    cell_colors={(0,0): colors['highlight']}, header_bg='', use_preset=False)
```

### 기본 Setup
```python
from pyhwpxlib import HwpxBuilder

doc = HwpxBuilder(theme='forest')  # 또는 다른 테마명
doc.add_heading("제목", level=1)
doc.add_paragraph("본문 텍스트")
doc.add_table([["A", "B"], ["1", "2"]])
doc.save("output.hwpx")
```

### Validation
```bash
pyhwpxlib validate output.hwpx
```

### HwpxBuilder Method Table

| 메서드 | 용도 |
|--------|------|
| `add_heading(text, level, alignment)` | 제목 (1~4) |
| `add_paragraph(text, bold, italic, font_size, text_color, alignment)` | 단락 |
| `add_table(data, header_bg, cell_colors, cell_margin, ...)` | 표 (프리셋 자동) |
| `add_bullet_list(items, bullet_char)` | 글머리 기호 목록 |
| `add_numbered_list(items, format_string)` | 번호 목록 |
| `add_nested_bullet_list(items)` | 중첩 글머리 [(level, text), ...] |
| `add_nested_numbered_list(items)` | 중첩 번호 [(level, text), ...] |
| `add_image(path, width, height)` | 로컬 이미지 |
| `add_image_from_url(url, filename, width, height)` | URL 이미지 다운로드 |
| `add_page_break()` | 페이지 나누기 |
| `add_line()` | 구분선 |
| `add_header(text)` | 머리말 |
| `add_footer(text)` | 꼬리말 |
| `add_page_number(pos)` | 페이지 번호 |
| `add_footnote(text, number)` | 각주 |
| `add_equation(script)` | 수식 |
| `add_highlight(text, color)` | 텍스트 하이라이트 |
| `add_rectangle(width, height, line_color)` | 사각형 도형 |
| `add_draw_line(x1, y1, x2, y2, line_color)` | 직선 도형 |
| `save(path)` | 저장 |

### Key API Examples

**생성자**:
```python
doc = HwpxBuilder(table_preset='corporate')
# table_preset: 'corporate' | 'government' | 'academic' | 'default'
# 프리셋이 표의 헤더색, 패딩, 행높이, 정렬, 줄무늬를 자동 적용
```

**표** — 프리셋 자동 적용:
```python
doc.add_table(
    data,                          # list[list[str]] — 필수
    header_bg='#395da2',           # 헤더 배경색. None=프리셋, ''=없음
    cell_colors={(1,0): '#d8e2ff'},# {(row,col): '#hex'} 셀별 배경색
    cell_margin=(283,283,200,200), # (L,R,T,B) 셀 패딩. None=프리셋
    col_widths=[12000, 30520],     # 컬럼별 너비. None=균등분할
    row_heights=[2400, 2000],      # 행별 높이. None=프리셋
    merge_info=[(0,0,0,2)],        # [(r1,c1,r2,c2)] 병합
    cell_aligns={(1,2): 'RIGHT'},  # {(row,col): 'CENTER'|'LEFT'|'RIGHT'}
    cell_styles={(0,0): {'text_color':'#f7f7ff','bold':True,'font_size':12}},
    cell_gradients={(0,0): {'start':'#FF0000','end':'#0000FF'}},
    width=42520,                   # 표 전체 너비 (기본 A4 content width)
    use_preset=False,              # False면 프리셋 자동 적용 안 함
)
```

**col_widths — LLM이 내용에 맞게 조정**:
- `col_widths`: 내용이 긴 컬럼은 넓게, 짧은 컬럼은 좁게 (합계 = 42520)
  - 텍스트 길이 기반 비율 계산: `내용 평균 글자수 × CJK 가중치(2)` 비율로 분배
  - 예: ['항목'(2글자), '설명'(20글자)] → col_widths=[8000, 34520]
- `row_heights`: 셀 내 텍스트가 한 줄이면 2000, 여러 줄이면 3000~4000

**키-값 표** (라벨+값, 헤더 없음):
```python
doc.add_table([
    ['설립', '1969년'],
    ['본사', '수원시'],
], col_widths=[10000, 32520], header_bg='',
    cell_styles={(r,0): {'bold': True, 'text_color': '#395da2'} for r in range(2)})
```

**이미지** — `add_image(path, width, height)` / `add_image_from_url(url, ...)`:
```python
doc.add_image("photo.png", width=21260, height=15000)
doc.add_image_from_url("https://example.com/image.png",
    filename="my_image.png", width=42520, height=21260)
```

**디자인 컴포넌트 — 표를 활용한 박스**:
```python
# 하이라이트 박스 (연한 라벤더블루)
doc.add_table([['핵심 요약 내용']],
    cell_colors={(0,0): '#d8e2ff'}, row_heights=[2400],
    cell_margin=(400,400,300,300), header_bg='',
    cell_styles={(0,0): {'text_color': '#2a5094'}}, use_preset=False)

# 콜아웃 박스 (연보라 — 인용, 주의)
doc.add_table([['인용문 또는 경고']],
    cell_colors={(0,0): '#e2dbfd'}, row_heights=[2000],
    cell_margin=(400,400,300,300), header_bg='',
    cell_styles={(0,0): {'text_color': '#514d68'}}, use_preset=False)

# 정보 박스 (연시안 — 참고)
doc.add_table([['참고 정보']],
    cell_colors={(0,0): '#cbe7f5'}, row_heights=[2000],
    cell_margin=(400,400,300,300), header_bg='',
    cell_styles={(0,0): {'text_color': '#3c5561'}}, use_preset=False)
```

**테마 팔레트 색상** (테마에서 자동 적용, 수동 참조도 가능):
```python
from pyhwpxlib import BUILTIN_THEMES
p = BUILTIN_THEMES['forest'].palette
p.primary             # '#2C5F2D' — 제목, 표 헤더 (테마별 다름)
p.on_primary          # '#f7f7ff' — primary 위 텍스트 (자동 대비)
p.on_surface          # '#2b3437' — 본문 (순검정 금지)
p.primary_container   # '#d8e8d8' — 하이라이트 박스
p.surface_low         # '#f3f6f0' — 줄무늬, 2차 배경
# 기존 DS dict도 하위 호환으로 유지됨 (default 테마 색상)
```

### Critical Rules for HwpxBuilder

- **pyhwpxlib 기반** — header.xml은 pyhwpxlib가 생성, section만 HwpxBuilder가 구성
- **줄바꿈 금지** — `<hp:t>` 안에 `\n` 넣으면 Whale 에러. 별도 `<hp:p>`로 분리
- **mimetype STORED** — ZIP의 mimetype 엔트리는 압축 없이(STORED) 첫 번째로
- **ET.tostring 금지** — XML 재직렬화 시 네임스페이스 변경으로 Whale 에러. 원본 문자열 직접 교체

> For full pyhwpxlib API (lists, shapes, equations, headers/footers, etc.) → see [references/api_full.md](references/api_full.md)

---

## Editing Existing Documents

**Read [references/editing.md](references/editing.md) for full details.** 요약:

### Step 1: Unpack
```bash
pyhwpxlib unpack document.hwpx -o unpacked/
```
Extracts all XML files to a folder.

### Step 2: Edit XML

Edit files in `unpacked/Contents/`. See [references/api_full.md](references/api_full.md) for XML Reference patterns.

**CRITICAL: Use original XML string replacement. Do NOT use ET.tostring() for re-serialization — it changes namespace prefixes and breaks Whale rendering.**

```python
# CORRECT — 원본 문자열 직접 교체
with open('unpacked/Contents/section0.xml', 'r') as f:
    xml = f.read()
xml = xml.replace('>성 명<', '>성 명  홍길동<', 1)
with open('unpacked/Contents/section0.xml', 'w') as f:
    f.write(xml)
```

```python
# WRONG — ET.tostring 재직렬화 (네임스페이스 깨짐)
root = ET.fromstring(xml)
new_xml = ET.tostring(root, encoding='unicode')  # Whale 에러!
```

### Advanced Operations

For complex edits (section extraction, paragraph insert/delete, table insertion, multi-run field filling), see [references/form_automation.md — Advanced XML Editing](references/form_automation.md).

### Step 3: Pack
```bash
pyhwpxlib pack unpacked/ -o output.hwpx
```
Creates HWPX with mimetype STORED as first entry.

### Validation + Lint
```bash
pyhwpxlib validate output.hwpx          # 구조 검증 (ZIP, 필수 파일, XML 파싱)
pyhwpxlib lint output.hwpx              # 렌더링 위험 검사 (5개 규칙)
pyhwpxlib font-check output.hwpx        # 폰트 해상 확인

# JSON 출력 (자동화/MCP/LLM용)
pyhwpxlib validate output.hwpx --json
pyhwpxlib lint output.hwpx --json
pyhwpxlib font-check output.hwpx --json
```

lint 규칙:
- `TEXT_NEWLINE_IN_RUN`: `<hp:t>` 안 `\n` → Whale 에러
- `EMPTY_FIRST_PARAGRAPH`: 빈 첫 문단 → 렌더링 문제
- `LONG_TEXT_RUN`: 500자+ run → 넘침 위험
- `UNESCAPED_AMPERSAND`: 이스케이프 안 된 `&`
- `FONT_NOT_IN_MAP`: fallback 폰트 사용

---

## Converting Documents

### HWP → HWPX (한글 5.x 바이너리 변환)
```python
from pyhwpxlib.hwp2hwpx import convert

convert("input.hwp", "output.hwpx")
# HWP 5.x 바이너리 → HWPX(ZIP/XML) 변환
# 표, 스타일, 병합, 머리말/꼬리말, 각주, 이미지 등 지원
```

```python
# 폴더 내 전체 HWP 파일 일괄 변환
import os
from pyhwpxlib.hwp2hwpx import convert

src_dir = "hwp_samples"
dst_dir = "hwpx_converted"
os.makedirs(dst_dir, exist_ok=True)

for f in os.listdir(src_dir):
    if f.endswith(".hwp"):
        convert(os.path.join(src_dir, f),
                os.path.join(dst_dir, f.replace(".hwp", ".hwpx")))
```

### Markdown → HWPX
```bash
python -m pyhwpxlib.cli md2hwpx input.md -o output.hwpx -s github
```
Styles: `github`, `vscode`, `minimal`, `academic`

**md 파일 → HWPX 변환 방법 2가지**:

| 방법 | 장점 | 단점 | 사용 시점 |
|------|------|------|----------|
| `md2hwpx` CLI | 빠름, 일관됨 | 단순 규칙 변환, 디자인 제한 | 단순 변환, 대량 처리 |
| LLM + HwpxBuilder | 문맥 이해, 디자인 적용 가능 | 느림 | 디자인 중요한 문서 |

**LLM이 md를 HwpxBuilder로 변환할 때 원칙**:
- 원문 텍스트를 그대로 사용한다 — 요약·재작성·생략 금지
- md의 구조(제목 계층, 표, 인용 등)를 보존한다
- 스타일링은 LLM이 주도적으로 판단하여 적용한다

### HTML → HWPX
```python
from pyhwpxlib.api import convert_html_file_to_hwpx
convert_html_file_to_hwpx("input.html", "output.hwpx")
# strip_links=True (기본값) — <a> 태그 자동 제거 (Whale fieldBegin 에러 방지)
```

### HWPX → HTML
```python
from pyhwpxlib.api import convert_hwpx_to_html
convert_hwpx_to_html("input.hwpx", "output.html")
```

### Text Extraction
```python
from pyhwpxlib.api import extract_text
text = extract_text("document.hwpx")
```

### HWP 5.x Binary Reading
```python
from pyhwpxlib.hwp_reader import read_hwp, detect_format

fmt = detect_format("file.hwp")  # "HWP" or "HWPX"
doc = read_hwp("file.hwp")
# doc['texts'], doc['paragraphs'], doc['tables'], doc['face_names']
```

---

## Critical Rules Summary

| # | Rule | Consequence |
|---|------|-------------|
| 1 | `<hp:t>` 안에 `\n` 금지 | Whale 에러 |
| 2 | secPr p에만 linesegarray | 글자 겹침 |
| 3 | ET.tostring 재직렬화 금지 | 네임스페이스 변경 → Whale 에러 |
| 4 | 원본 ZIP + 텍스트 교체 | 서식 100% 보존 유일한 방법 |
| 5 | condense 보존 | JUSTIFY 글자 벌어짐 방지 |
| 6 | styleIDRef 보존 | 들여쓰기 유지 |
| 7 | mimetype STORED | OPC 규격 필수 |
| 8 | `<a href>` 제거 | fieldBegin/fieldEnd Whale 에러 |
| 9 | 원문 텍스트 보존 — 요약·재작성·생략 금지 | 원문 왜곡 방지 |
| 10 | 원문 성격에 맞지 않는 양식 강제 금지 | 리서치문에 기업보고서 표지 등 |
| 11 | LLM은 스타일링은 자유롭게, 내용은 충실하게 | 디자인은 판단, 텍스트는 보존 |
| 12 | header/footer/page_number는 SecPr 뒤에 삽입 | HwpxBuilder가 자동 처리 (deferred) |
| 13 | 셀 내 긴 텍스트는 명시적 `\n` 삽입 (30자 기준) | rhwp 렌더러가 자동 줄바꿈 안 함 → 글자 겹침 |
| 14 | 긴 표는 ~15행 단위로 분할 + `add_page_break()` | rhwp가 표 자동 페이지 분할 안 함 → 내용 잘림 |
| 15 | 기존 표 높이 수정 시 `<hp:sz>` + `<hp:cellSz>` 둘 다 변경 | 한쪽만 바꾸면 렌더러가 크기 반영 안 함 |
| 16 | HWP Color는 BGR — `_colorref_to_hex()`로 변환 | 0xFF0000 = 파란색 (빨간색 아님) |
| 17 | landscape: WIDELY=세로, NARROWLY=가로 (반전) | 이름과 반대, 혼동 주의 |
| 18 | TextBox = `hp:rect` + `hp:drawText`, shapeComment 선행 필수 | 순서 역전 시 parse error |
| 19 | Polygon 꼭짓점: 마지막 점 = 첫 점 (닫힘) | 누락 시 열린 도형 |
| 20 | breakNonLatinWord = `KEEP_WORD` 필수 | `BREAK_WORD` 시 글자 퍼짐 |
| 21 | fwSpace/nbSpace/hyphen는 extended control 아님 | 뒤 14바이트 스킵 → 텍스트 소실 |
| 22 | 빈 셀 채우기: cellAddr 앵커 + `<hp:t/>` 교체 | 문자열 교체 불가, `_patch_empty_cell()` 사용 |
| 23 | 라벨 탐색 시 colSpan/rowSpan 반영 | 병합 셀 무시하면 잘못된 위치 |
| 24 | 단계별 빌드 프리뷰: save → render → Read PNG | `hwpx_build_step` MCP tool 또는 수동 루프 |

---

## Getting Started (시작 가이드)

### 1. 설치
```bash
pip install pyhwpxlib
```

### 2. 첫 문서 만들기
```python
from pyhwpxlib import HwpxBuilder

doc = HwpxBuilder()
doc.add_heading("첫 번째 문서", level=1)
doc.add_paragraph("pyhwpxlib으로 만든 문서입니다.")
doc.add_table([["이름", "나이"], ["홍길동", "30"]])
doc.save("my_first.hwpx")
```
→ `my_first.hwpx`를 Whale 또는 한컴오피스에서 열어 확인

### 3. 기존 HWP 파일 변환
```bash
# HWP 5.x → HWPX
python -c "from pyhwpxlib.hwp2hwpx import convert; convert('old.hwp', 'new.hwpx')"

# 마크다운 → HWPX
pyhwpxlib md2hwpx report.md -o report.hwpx
```

### 4. 기존 문서 편집
```bash
pyhwpxlib unpack document.hwpx -o unpacked/   # 풀기
# unpacked/Contents/section0.xml 편집
pyhwpxlib pack unpacked/ -o output.hwpx        # 묶기
pyhwpxlib validate output.hwpx                 # 검증
```

### 5. 양식 자동 채우기
```python
from pyhwpxlib.api import fill_template, fill_template_checkbox

# {{key}} 패턴 — 권장 (안전하고 명확)
fill_template("양식.hwpx",
    data={"이름": "홍길동", "회사": "A&B Corp"},  # {{이름}} → 홍길동
    output_path="완성.hwpx")

# 체크박스 포함
fill_template_checkbox("양식.hwpx",
    data={"이름": "홍길동"},
    checks=["동의함"],  # □ → ■
    output_path="완성.hwpx")
```

---

## Dependencies

- **pyhwpxlib**: `pip install pyhwpxlib` (핵심 라이브러리)
- **olefile**: HWP 5.x 읽기용 (자동 설치됨)

---

## Skill Update (스킬 동기화)

프로젝트 `skill/`과 설치된 `~/.claude/skills/hwpx/` 간 동기화:

```bash
# 상태 확인 — 어디가 다른지 보기
python -m pyhwpxlib.update_skill status

# Push — 프로젝트 → 설치된 스킬
python -m pyhwpxlib.update_skill push

# Pull — 설치된 스킬 → 프로젝트
python -m pyhwpxlib.update_skill pull

# Backup — 현재 설치된 스킬 스냅샷
python -m pyhwpxlib.update_skill backup
```

---

## Reference Files

| File | Contents |
|------|----------|
| [references/api_full.md](references/api_full.md) | pyhwpxlib full function reference, XML reference, page sizes, size conversion table |
| [references/document_types.md](references/document_types.md) | Document type specs (5 types), indent guide, TOC patterns, cover page patterns, document structure guide, table design guide |
| [references/form_automation.md](references/form_automation.md) | fill_template, batch generate, schema extraction, checkbox patterns, advanced XML editing |
| [references/design_guide.md](references/design_guide.md) | 주제별 색상 팔레트 10종, 레이아웃 패턴, 타이포그래피, QA 프로세스 |
| [references/editing.md](references/editing.md) | 편집 워크플로우, XML 규칙, 흔한 실수, 양식 채우기, 고급 편집 (표 삽입, 섹션 추출) |
